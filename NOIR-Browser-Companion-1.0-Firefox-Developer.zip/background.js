const ext=globalThis.browser||globalThis.chrome;
/* A tab must be armed by the user. Only media GET URLs are observed. */
if(typeof importScripts==='function')importScripts('core.js');
const sessions=ext.storage.session;let memory={};
async function read(){return sessions?(await sessions.get('capture')).capture||{}:memory;}
async function write(value){if(sessions)await sessions.set({capture:value});else memory=value;}
let queue=Promise.resolve();function serial(task){queue=queue.then(task).catch(()=>{});return queue;}
ext.runtime.onMessage.addListener((msg,sender,reply)=>{
 if(sender.id!==ext.runtime.id)return;
 serial(async()=>{
  if(msg.type==='arm'){
   const tab=await ext.tabs.get(msg.tabId);if(!NoirCapture.videoId(tab.url))return reply({error:'Open a YouTube watch page first.'});
   await write({tabId:tab.id,page:tab.url,title:tab.title,tracks:[]});reply({ok:true});
  }else if(msg.type==='state')reply(await read());
  else if(msg.type==='clear'){await write({});reply({ok:true});}
 });return true;
});
ext.webRequest.onHeadersReceived.addListener(details=>{
 serial(async()=>{
  const state=await read();if(state.tabId!==details.tabId||![200,206].includes(details.statusCode))return;
  const tab=await ext.tabs.get(details.tabId);if(NoirCapture.videoId(tab.url)!==NoirCapture.videoId(state.page)){await write({});return;}
  const mime=(details.responseHeaders||[]).find(h=>h.name.toLowerCase()==='content-type')?.value;
  const item=NoirCapture.track(details.url,mime,details.method);if(!item)return;
  const identity=t=>t.tag+':'+t.language;
  state.tracks=state.tracks.filter(t=>identity(t)!==identity(item));state.tracks.push(item);state.tracks=state.tracks.slice(-50);state.title=tab.title;await write(state);
 });
},{urls:['https://*.googlevideo.com/*']},['responseHeaders']);
ext.tabs.onRemoved.addListener(id=>serial(async()=>{if((await read()).tabId===id)await write({});}));
ext.tabs.onUpdated.addListener((id,change)=>{if(change.url)serial(async()=>{const state=await read();if(state.tabId===id&&NoirCapture.videoId(change.url)!==NoirCapture.videoId(state.page))await write({});});});
