/* No account credentials are read or exported. */
(function(root){
const heights={18:360,22:720,37:1080,38:3072,59:480,78:480,133:240,134:360,135:480,136:720,137:1080,138:2160,160:144,242:240,243:360,244:480,247:720,248:1080,271:1440,272:2160,278:144,298:720,299:1080,302:720,303:1080,308:1440,313:2160,315:2160,394:144,395:240,396:360,397:480,398:720,399:1080,400:1440,401:2160};
function track(value,mime,method='GET',now=Date.now()){
 try{
  if(method!=='GET'||typeof value!=='string'||value.length>32768)return null;
  const u=new URL(value),q=u.searchParams;
  if(u.protocol!=='https:'||!u.hostname.endsWith('.googlevideo.com')||u.username||u.password||u.port&&u.port!=='443'||u.pathname!=='/videoplayback'||u.hash)return null;
  const keys=[...q.keys()];if(new Set(keys).size!==keys.length)return null;
  if(q.has('sq')||q.has('sabr')||q.get('otf')==='3')return null;
  if(!/^\d+$/.test(q.get('expire')||'')||Number(q.get('expire'))<=now/1000+30||!/^\d{1,5}$/.test(q.get('itag')||'')||!/^\d+$/.test(q.get('clen')||''))return null;
  const bytes=Number(q.get('clen'));if(!Number.isSafeInteger(bytes)||bytes<=0||bytes>1099511627776)return null;
  mime=(mime||q.get('mime')||'').split(';')[0].trim();if(!/^(video|audio)\/(mp4|webm)$/.test(mime))return null;
  if(q.has('mime')&&q.get('mime')!==mime)return null;
  // Range is a transport hint, not a new file. Never remove signed parameters.
  if(q.has('range')){if((q.get('sparams')||'').split(',').includes('range')||(q.get('lsparams')||'').split(',').includes('range'))return null;q.delete('range');}
  const tag=q.get('itag'),height=heights[tag]||0,muxed=['18','22','37','38','59','78'].includes(tag);
  return {url:u.href,mime,bytes,height,label:height?height+'p':'itag '+tag,language:q.get('lang')||'Browser audio',tag,muxed};
 }catch{return null;}
}
function videoId(value){try{const u=new URL(value);return u.protocol==='https:'&&['youtube.com','www.youtube.com','m.youtube.com'].includes(u.hostname)&&u.pathname==='/watch'&&/^[\w-]{11}$/.test(u.searchParams.get('v')||'')?u.searchParams.get('v'):null;}catch{return null;}}
function bundle(state,video,audio,agent){
 if(!state||!videoId(state.page)||!video||!track(video.url,video.mime))throw Error('Capture a fresh video track.');
 if(!video.muxed&&(!audio||!track(audio.url,audio.mime)||!audio.mime.startsWith('audio/')))throw Error('Select a captured audio track too.');
 return {noirDownload:1,videoId:videoId(state.page),title:(state.title||'Browser video').replace(/ - YouTube$/,'').slice(0,500),agent,video,...(!video.muxed?{audio}:{})};
}
const api={track,videoId,bundle};root.NoirCapture=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
